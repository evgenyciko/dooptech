<nav class="nav">
        <div class="container">
            <!-- <div class="logo rounded-circle ">
              <a href="<?php echo e(url('/')); ?>">
                <img  src="<?php echo e(asset('images/logo-2.png')); ?>"  width="40" height="40"  alt="">
              </a>
            </div> -->
            <div id="mainListDiv" class="main_list">
                <ul class="navlinks">
                      <!-- Authentication Links -->
                      <?php if(Route::has('login')): ?>
                      <?php if(auth()->guard()->check()): ?>
                        <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                      <?php else: ?>
                      <li class="login"><a href="#">Login</a></li>
                      <?php if(Route::has('register')): ?>
                      <li class="register"><a href="#">Register</a></li>
                      <?php endif; ?>
                      <?php endif; ?>
                      <?php endif; ?>
                </ul>
            </div>
            <span class="navTrigger ">
              <div class="burger">
                <i></i>
                <i></i>
                <i></i>
              </div>  
            </span>
        </div>
    </nav>
<?php /**PATH D:\NEW HOBI\Binary\chalenge chapter 3\awal_penderitaan-master\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>
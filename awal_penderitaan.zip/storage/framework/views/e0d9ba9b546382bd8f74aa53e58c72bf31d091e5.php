<div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-labelledby="registerModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="d-flex justify-content-center">
                <div class="sign-up-content rounded-circle rounded-circle">
                    <form id="registerForm" class="signup-form" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-textbox">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="nameInput" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus />
                            <span class="invalid-feedback" role="alert" id="nameError">
                                <strong></strong>
                            </span>
                        </div>
                        <div class="form-textbox">
                            <label for="email">Email</label>
                            <input type="text" name="email" id="emailInput" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" />
                            <span class="invalid-feedback" role="alert" id="emailError">
                                <strong></strong>
                            </span>
                        </div>
                        <div class="form-textbox">
                            <label for="pass">Password</label>
                            <input type="password" name="password" id="passwordInput" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="new-password" />
                            <span class="invalid-feedback" role="alert" id="passwordError">
                                <strong></strong>
                            </span>
                        </div>
                        <div class="form-textbox">
                            <label for="pass">Confirm Password</label>
                            <input id="password-confirm" type="password" name="password_confirmation" class="" required autocomplete="new-password" />
                        </div>
                        <div class="col-md-12 ml-5">
                            <label class="radio">Mahasiswa
                                <input value="user" type="radio" checked="checked" name="status_user">
                                <span class="checkround"></span>
                            </label>
                            <label class="radio">Pembimbing
                                <input value="admin" type="radio" name="status_user">
                                <span class="checkround"></span>
                            </label>
                        </div>
                        <div class="d-flex justify-content-center mt-5">
                            <input type="submit" name="submit" value="Create account" />
                        </div>
                    </form>
                  
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<script>
    $(function() {
        $('#registerForm').submit(function(e) {
            e.preventDefault();
            let formData = $(this).serializeArray();
            $(".invalid-feedback").children("strong").text("");
            $("#registerForm input").removeClass("is-invalid");
            $.ajax({
                method: "POST",
                headers: {
                    Accept: "application/json"
                },
                url: "<?php echo e(route('register')); ?>",
                data: formData,
                success: () => window.location.assign("<?php echo e(route('home')); ?>"),
                error: (response) => {
                    if (response.status === 422) {
                        let errors = response.responseJSON.errors;
                        Object.keys(errors).forEach(function(key) {
                            $("#" + key + "Input").addClass("is-invalid");
                            $("#" + key + "Error").children("strong").text(errors[key][0]);
                        });
                    } else {
                        window.location.reload();
                    }
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?><?php /**PATH D:\NEW HOBI\Binary\chalenge chapter 3\awal_penderitaan-master\resources\views/partials/register.blade.php ENDPATH**/ ?>
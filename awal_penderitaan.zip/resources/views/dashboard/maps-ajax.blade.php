<div class="rounded border border-info" style="width: 705px; height: 460px;">
  <div id="mapid" style="width: 700px; height: 450px;"></div>
</div>
